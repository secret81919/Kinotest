(async () => {
  await requireAuth({ admin: true });
  const file = $('#file'), drop = $('#drop');
  const TYPES = { file: 'Загружен', youtube: 'YouTube', url: 'Ссылка' };

  async function load() {
    const videos = await api('/api/videos');
    $('#count').textContent = videos.length ? `Видео: ${videos.length}` : 'Пока ничего нет — загрузите первое видео.';
    const list = $('#list');
    list.replaceChildren();
    for (const v of videos) {
      const it = document.createElement('div'); it.className = 'item';
      const th = document.createElement('div'); th.className = 'thumb';
      th.style.setProperty('--h', hue(v.title));
      if (v.poster) th.style.backgroundImage = `url("${v.poster}")`;
      const meta = document.createElement('div'); meta.className = 'meta';
      const b = document.createElement('b'); b.textContent = v.title;
      const s = document.createElement('span'); s.className = 'badge'; s.textContent = TYPES[v.type];
      meta.append(b, s);
      const del = document.createElement('button'); del.className = 'btn sm danger'; del.textContent = 'Удалить';
      del.onclick = async () => {
        if (!confirm(`Удалить «${v.title}»?`)) return;
        await api('/api/admin/videos/' + v.id, { method: 'DELETE' });
        toast('Удалено'); load();
      };
      it.append(th, meta, del);
      list.append(it);
    }
  }

  /* выбор файла */
  const showFile = () => {
    const f = file.files[0];
    $('#dropText').textContent = f ? `${f.name} (${(f.size / 1048576).toFixed(0)} МБ)` : 'Перетащите файл сюда или нажмите';
    if (f && !$('#title').value) $('#title').value = f.name.replace(/\.[^.]+$/, '');
  };
  drop.onclick = () => file.click();
  drop.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); file.click(); } };
  file.onchange = showFile;
  drop.ondragover = (e) => { e.preventDefault(); drop.classList.add('over'); };
  drop.ondragleave = () => drop.classList.remove('over');
  drop.ondrop = (e) => {
    e.preventDefault(); drop.classList.remove('over');
    if (e.dataTransfer.files.length) { file.files = e.dataTransfer.files; showFile(); }
  };

  /* загрузка с прогрессом */
  $('#upForm').onsubmit = (e) => {
    e.preventDefault();
    const err = $('#upError'); err.textContent = '';
    const f = file.files[0];
    if (!f) { err.textContent = 'Выберите видеофайл'; return; }
    const fd = new FormData();
    fd.append('title', $('#title').value);
    fd.append('description', $('#desc').value);
    fd.append('video', f);
    if ($('#poster').files[0]) fd.append('poster', $('#poster').files[0]);

    const btn = $('#upBtn'), prog = $('#progress'), bar = $('#bar');
    btn.disabled = true; prog.hidden = false; bar.style.width = '0';
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/admin/videos');
    xhr.upload.onprogress = (ev) => {
      if (!ev.lengthComputable) return;
      const p = Math.round((ev.loaded / ev.total) * 100);
      bar.style.width = p + '%';
      btn.textContent = p < 100 ? `Загружаем… ${p}%` : 'Сохраняем…';
    };
    xhr.onload = () => {
      btn.disabled = false; btn.textContent = 'Загрузить'; prog.hidden = true;
      if (xhr.status === 200) {
        toast('Видео загружено');
        e.target.reset(); showFile(); load();
      } else {
        let m = 'Не удалось загрузить'; try { m = JSON.parse(xhr.responseText).error || m; } catch {}
        err.textContent = m;
      }
    };
    xhr.onerror = () => { btn.disabled = false; btn.textContent = 'Загрузить'; prog.hidden = true; err.textContent = 'Соединение прервано'; };
    xhr.send(fd);
  };

  /* по ссылке */
  $('#linkForm').onsubmit = async (e) => {
    e.preventDefault();
    const err = $('#lError'); err.textContent = '';
    try {
      await api('/api/admin/videos/link', { method: 'POST',
        body: { url: $('#lUrl').value, title: $('#lTitle').value, description: $('#lDesc').value } });
      toast('Видео добавлено'); e.target.reset(); load();
    } catch (x) { err.textContent = x.message; }
  };

  load();
})();
