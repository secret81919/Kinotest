(async () => {
  const me = await requireAuth();
  const err = $('#error');

  async function openRoom(body) {
    err.textContent = '';
    try {
      const { id } = await api('/api/rooms', { method: 'POST', body });
      location.href = '/room/' + id;
    } catch (e) { err.textContent = e.message; }
  }

  $('#joinForm').onsubmit = async (e) => {
    e.preventDefault();
    const code = $('#code').value.trim().toUpperCase();
    if (!code) return;
    try { await api('/api/rooms/' + encodeURIComponent(code)); location.href = '/room/' + code; }
    catch { err.textContent = 'Комната с таким кодом не найдена'; }
  };
  $('#linkForm').onsubmit = (e) => {
    e.preventDefault();
    const url = $('#link').value.trim();
    if (url) openRoom({ url });
  };

  const videos = await api('/api/videos');
  const grid = $('#grid'), empty = $('#empty');
  if (!videos.length) {
    empty.hidden = false;
    empty.innerHTML = me.role === 'admin'
      ? 'В библиотеке пока пусто. <a href="/admin">Загрузите первое видео</a> в админке.'
      : 'В библиотеке пока пусто. Администратор скоро добавит видео — а пока можно вставить ссылку выше.';
  }
  for (const v of videos) {
    const b = document.createElement('button');
    b.className = 'btn primary sm';
    b.textContent = 'Создать комнату';
    b.onclick = () => openRoom({ videoId: v.id });
    grid.append(videoCard(v, [b]));
  }
})();
