(async () => {
  try { await api('/api/me'); location.replace('/app'); return; } catch {}

  let mode = 'register';
  const el = { form: $('#form'), user: $('#username'), pass: $('#password'), err: $('#error'),
    title: $('#title'), submit: $('#submit'), meter: $('#meter'), meterText: $('#meterText'), toggle: $('#toggle') };

  function setMode(m) {
    mode = m;
    document.querySelectorAll('.seg button').forEach((b) => b.classList.toggle('on', b.dataset.mode === m));
    const reg = m === 'register';
    el.title.textContent = reg ? 'Создайте аккаунт' : 'С возвращением!';
    el.submit.textContent = reg ? 'Получить билет' : 'Войти в зал';
    el.pass.autocomplete = reg ? 'new-password' : 'current-password';
    el.meter.hidden = !reg;
    el.err.textContent = '';
  }
  document.querySelectorAll('.seg button').forEach((b) => (b.onclick = () => setMode(b.dataset.mode)));

  el.toggle.onclick = () => {
    const show = el.pass.type === 'password';
    el.pass.type = show ? 'text' : 'password';
    el.toggle.textContent = show ? 'Скрыть' : 'Показать';
  };

  const levels = [['', '#e6d3b6'], ['Слабый', '#e5484d'], ['Так себе', '#f0a030'], ['Хороший', '#9bc53d'], ['Отличный', '#2fa84f']];
  el.pass.addEventListener('input', () => {
    const p = el.pass.value;
    let s = 0;
    if (p.length >= 6) s++;
    if (p.length >= 9 && /[a-zа-яё]/i.test(p) && /\d/.test(p)) s++;
    if (/[A-ZА-ЯЁ]/.test(p) && /[a-zа-яё]/.test(p)) s++;
    if (/[^\wа-яё]/i.test(p) || p.length >= 13) s++;
    if (!p) s = 0;
    el.meter.querySelectorAll('i').forEach((i, n) => (i.style.background = n < s ? levels[s][1] : levels[0][1]));
    el.meterText.textContent = levels[s][0];
  });

  el.form.addEventListener('submit', async (e) => {
    e.preventDefault();
    el.err.textContent = '';
    if (!el.user.value.trim() || !el.pass.value) { el.err.textContent = 'Заполните имя и пароль'; return; }
    el.submit.disabled = true;
    try {
      await api(mode === 'register' ? '/api/register' : '/api/login', {
        method: 'POST', body: { username: el.user.value, password: el.pass.value },
      });
      location.href = '/app';
    } catch (err) {
      el.err.textContent = err.message;
      el.submit.disabled = false;
    }
  });
})();
