const $ = (s, el = document) => el.querySelector(s);

async function api(url, opts = {}) {
  const o = { credentials: 'same-origin', ...opts };
  if (o.body && !(o.body instanceof FormData)) {
    o.headers = { 'Content-Type': 'application/json', ...o.headers };
    o.body = JSON.stringify(o.body);
  }
  const r = await fetch(url, o);
  let d = {};
  try { d = await r.json(); } catch {}
  if (!r.ok) { const e = new Error(d.error || 'Что-то пошло не так'); e.status = r.status; throw e; }
  return d;
}

function toast(msg) {
  const t = document.createElement('div');
  t.className = 'toast';
  t.textContent = msg;
  document.body.append(t);
  setTimeout(() => t.remove(), 2600);
}

const hue = (s) => { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };

function avatar(name) {
  const a = document.createElement('div');
  a.className = 'avatar';
  a.textContent = (name[0] || '?').toUpperCase();
  a.style.background = `hsl(${hue(name)} 55% 45%)`;
  return a;
}

async function requireAuth({ admin = false } = {}) {
  try {
    const me = await api('/api/me');
    if (admin && me.role !== 'admin') { location.href = '/app'; return new Promise(() => {}); }
    fillNav(me);
    return me;
  } catch {
    location.href = '/';
    return new Promise(() => {});
  }
}

function fillNav(me) {
  const nav = $('#nav');
  if (!nav) return;
  if (me.role === 'admin') {
    const a = document.createElement('a');
    a.className = 'btn sm'; a.href = '/admin'; a.textContent = 'Админка';
    nav.append(a);
  }
  const chip = document.createElement('div');
  chip.className = 'userchip';
  chip.append(avatar(me.username), document.createTextNode(me.username));
  const out = document.createElement('button');
  out.className = 'btn sm'; out.textContent = 'Выйти';
  out.onclick = async () => { await api('/api/logout', { method: 'POST' }); location.href = '/'; };
  nav.append(chip, out);
}

function videoCard(v, actions) {
  const card = document.createElement('div');
  card.className = 'card';
  const p = document.createElement('div');
  p.className = 'poster';
  p.style.setProperty('--h', hue(v.title));
  if (v.poster) { p.style.backgroundImage = `url("${v.poster}")`; } else { p.textContent = v.title[0].toUpperCase(); }
  const body = document.createElement('div');
  body.className = 'body';
  const h = document.createElement('h3'); h.textContent = v.title;
  const d = document.createElement('p'); d.textContent = v.description || '';
  body.append(h, d, ...actions);
  card.append(p, body);
  return card;
}
