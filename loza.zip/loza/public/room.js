(async () => {
  const me = await requireAuth();
  const roomId = location.pathname.split('/').pop().toUpperCase();
  $('#code').textContent = roomId;

  let room;
  try { room = await api('/api/rooms/' + roomId); }
  catch {
    $('#room').innerHTML = '<div class="empty" style="grid-column:1/-1;align-self:start"><h2 style="margin-bottom:10px">Комната не найдена</h2>' +
      'Возможно, сервер перезапускался или код введён с ошибкой. <a href="/app">Создайте новую комнату</a>.</div>';
    return;
  }
  const video = room.video;
  const stage = $('#stage');
  $('#vtitle').textContent = video.title;
  $('#vdesc').textContent = video.description || '';
  $('#gateTitle').textContent = video.title;
  document.title = `${video.title} — Ложа`;

  /* ---------- состояние синхронизации ---------- */
  // desired — то, что должно происходить сейчас у всех
  let desired = { playing: false, time: 0, at: Date.now() };
  const setDesired = (playing, time) => { desired = { playing, time, at: Date.now() }; };
  const expected = () => (desired.playing ? desired.time + (Date.now() - desired.at) / 1000 : desired.time);
  let entered = false;
  const handlers = { play() {}, pause() {}, seek() {} };

  /* ---------- плееры ---------- */
  function html5Player(src, poster) {
    const v = document.createElement('video');
    v.controls = true; v.playsInline = true; v.preload = 'auto'; v.src = src;
    if (poster) v.poster = poster;
    stage.prepend(v);
    v.addEventListener('play', () => handlers.play(v.currentTime));
    v.addEventListener('pause', () => handlers.pause(v.currentTime));
    v.addEventListener('seeked', () => handlers.seek(v.currentTime));
    return {
      ready: Promise.resolve(),
      play: () => v.play(),
      pause: () => v.pause(),
      seek: (t) => { v.currentTime = t; },
      time: () => v.currentTime,
    };
  }

  function youtubePlayer(id) {
    const holder = document.createElement('div');
    holder.id = 'yt';
    stage.prepend(holder);
    let p, ytState = -1, lastT = 0, lastTick = Date.now();
    const ready = new Promise((resolve) => {
      const boot = () => {
        p = new YT.Player('yt', {
          videoId: id, width: '100%', height: '100%',
          playerVars: { playsinline: 1, rel: 0 },
          events: {
            onReady: () => resolve(),
            onStateChange: (e) => {
              ytState = e.data;
              if (e.data === 1) handlers.play(p.getCurrentTime());
              else if (e.data === 2) handlers.pause(p.getCurrentTime());
            },
          },
        });
      };
      if (window.YT && YT.Player) boot();
      else {
        window.onYouTubeIframeAPIReady = boot;
        const s = document.createElement('script');
        s.src = 'https://www.youtube.com/iframe_api';
        document.head.append(s);
      }
    });
    // у YouTube нет события перемотки — ловим скачки времени
    setInterval(() => {
      if (!p || !p.getCurrentTime) return;
      const t = p.getCurrentTime(), now = Date.now();
      if (ytState === 3) { lastT = t; lastTick = now; return; } // буферизация
      const exp = lastT + (ytState === 1 ? (now - lastTick) / 1000 : 0);
      if (Math.abs(t - exp) > 1.5) handlers.seek(t);
      lastT = t; lastTick = now;
    }, 500);
    return {
      ready,
      play: async () => { await ready; p.playVideo(); },
      pause: async () => { await ready; p.pauseVideo(); },
      seek: (t) => { if (p && p.seekTo) p.seekTo(t, true); },
      time: () => (p && p.getCurrentTime ? p.getCurrentTime() : 0),
    };
  }

  const player = video.type === 'youtube' ? youtubePlayer(video.src) : html5Player(video.src, video.poster);

  /* ---------- применяем состояние от других ---------- */
  async function apply(state) {
    setDesired(state.playing, state.time);
    await player.ready;
    if (Math.abs(player.time() - state.time) > 0.7) player.seek(state.time);
    if (state.playing) { try { await player.play(); } catch { needTap(); } }
    else player.pause();
  }

  function needTap() {
    entered = false;
    $('#gateText').textContent = 'Браузер приостановил воспроизведение. Нажмите, чтобы продолжить.';
    $('#enter').textContent = 'Продолжить';
    $('#gate').hidden = false;
  }
  $('#enter').onclick = () => {
    entered = true;
    $('#gate').hidden = true;
    apply({ playing: desired.playing, time: expected() });
  };

  /* ---------- свои действия -> всем ---------- */
  const emit = (action, time) => socket.emit('control', { action, time });
  handlers.play = (t) => {
    if (!entered || (desired.playing && Math.abs(t - expected()) < 1.5)) return;
    setDesired(true, t); emit('play', t);
  };
  handlers.pause = (t) => {
    if (!entered || (!desired.playing && Math.abs(t - desired.time) < 1.5)) return;
    setDesired(false, t); emit('pause', t);
  };
  handlers.seek = (t) => {
    if (!entered || Math.abs(t - expected()) < 1.5) return;
    setDesired(desired.playing, t); emit('seek', t);
  };

  /* ---------- сокет ---------- */
  const socket = io();
  const feed = $('#feed');

  socket.on('connect', () => {
    socket.emit('join', roomId, (res) => {
      if (res.error) { toast(res.error); return; }
      feed.replaceChildren();
      res.chat.forEach(addMsg);
      renderMembers(res.members);
      setDesired(res.state.playing, res.state.time);
      if (entered) apply(res.state);
    });
  });
  socket.on('disconnect', () => toast('Связь потеряна, переподключаемся…'));

  const VERB = { play: 'запустил(а) видео', pause: 'поставил(а) на паузу', seek: 'перемотал(а)' };
  socket.on('control', ({ action, time, by }) => {
    const playing = action === 'play' ? true : action === 'pause' ? false : desired.playing;
    addMsg({ system: true, text: `${by} ${VERB[action]}` });
    setDesired(playing, time);
    if (entered) apply({ playing, time });
  });

  /* ---------- чат ---------- */
  function addMsg(m) {
    const d = document.createElement('div');
    if (m.system) {
      d.className = 'sys';
      d.textContent = m.text;
    } else {
      d.className = 'msg' + (m.user === me.username ? ' mine' : '');
      const body = document.createElement('div'); body.className = 'bubble';
      const head = document.createElement('div');
      const b = document.createElement('b'); b.textContent = m.user;
      const t = document.createElement('time');
      t.textContent = new Date(m.ts).toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' });
      head.append(b, t);
      const p = document.createElement('p'); p.textContent = m.text;
      body.append(head, p);
      d.append(avatar(m.user), body);
    }
    const nearBottom = feed.scrollHeight - feed.scrollTop - feed.clientHeight < 80;
    feed.append(d);
    if (nearBottom || m.user === me.username) feed.scrollTop = feed.scrollHeight;
  }
  socket.on('chat', addMsg);

  $('#chatForm').onsubmit = (e) => {
    e.preventDefault();
    const input = $('#chatInput');
    const text = input.value.trim();
    if (!text) return;
    socket.emit('chat', text);
    input.value = '';
  };

  /* ---------- участники и реакции ---------- */
  function renderMembers(names) {
    const who = $('#who');
    who.replaceChildren(document.createTextNode('В зале:'));
    for (const n of names) {
      const c = document.createElement('span'); c.className = 'chip';
      c.append(avatar(n), document.createTextNode(n));
      who.append(c);
    }
  }
  socket.on('members', renderMembers);

  const react = $('#react');
  for (const e of ['❤️', '😂', '😮', '👏', '🔥']) {
    const b = document.createElement('button');
    b.textContent = e; b.setAttribute('aria-label', 'Реакция ' + e);
    b.onclick = () => socket.emit('reaction', e);
    react.append(b);
  }
  socket.on('reaction', ({ emoji }) => {
    const f = document.createElement('span');
    f.className = 'floater'; f.textContent = emoji;
    f.style.left = 8 + Math.random() * 80 + '%';
    $('#floaters').append(f);
    setTimeout(() => f.remove(), 2700);
  });

  /* ---------- ссылка на комнату ---------- */
  $('#copy').onclick = async () => {
    try { await navigator.clipboard.writeText(location.href); toast('Ссылка скопирована'); }
    catch { prompt('Скопируйте ссылку:', location.href); }
  };
})();
