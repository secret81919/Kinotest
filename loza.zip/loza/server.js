const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { Server } = require('socket.io');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const cookie = require('cookie');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(ROOT, 'uploads');
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

/* ---------- секрет для токенов ---------- */
const SECRET_FILE = path.join(DATA_DIR, 'secret.txt');
let SECRET = process.env.JWT_SECRET;
if (!SECRET) {
  if (fs.existsSync(SECRET_FILE)) SECRET = fs.readFileSync(SECRET_FILE, 'utf8');
  else {
    SECRET = crypto.randomBytes(32).toString('hex');
    fs.writeFileSync(SECRET_FILE, SECRET);
  }
}

/* ---------- «база данных» в json-файле ---------- */
const DB_FILE = path.join(DATA_DIR, 'db.json');
let db = { users: [], videos: [] };
if (fs.existsSync(DB_FILE)) {
  try { db = { ...db, ...JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) }; }
  catch (e) { console.error('Не удалось прочитать db.json', e); }
}
const saveDb = () => fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
const uid = () => crypto.randomBytes(6).toString('hex');

/* ---------- авторизация ---------- */
const COOKIE = 'loza_token';
const publicUser = (u) => ({ id: u.id, username: u.username, role: u.role });

function userFromToken(token) {
  if (!token) return null;
  try {
    const { id } = jwt.verify(token, SECRET);
    return db.users.find((u) => u.id === id) || null;
  } catch { return null; }
}
function setAuthCookie(res, user) {
  res.cookie(COOKIE, jwt.sign({ id: user.id }, SECRET, { expiresIn: '30d' }), {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.COOKIE_SECURE === '1',
    maxAge: 30 * 24 * 3600 * 1000,
  });
}
function auth(req, res, next) {
  const u = userFromToken(req.cookies[COOKIE]);
  if (!u) return res.status(401).json({ error: 'Нужно войти' });
  req.user = u;
  next();
}
function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Только для администратора' });
  next();
}

// простая защита от подбора пароля: 10 попыток за 10 минут с одного IP
const attempts = new Map();
function tooMany(req) {
  const ip = req.ip, now = Date.now();
  const list = (attempts.get(ip) || []).filter((t) => now - t < 10 * 60 * 1000);
  list.push(now);
  attempts.set(ip, list);
  return list.length > 10;
}

/* ---------- express ---------- */
const app = express();
const server = http.createServer(app);
app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());

app.post('/api/register', async (req, res) => {
  if (tooMany(req)) return res.status(429).json({ error: 'Слишком много попыток. Подождите немного' });
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');
  if (!/^[\p{L}\d_]{3,20}$/u.test(username))
    return res.status(400).json({ error: 'Имя: 3–20 символов — буквы, цифры и подчёркивание' });
  if (password.length < 6)
    return res.status(400).json({ error: 'Пароль должен быть не короче 6 символов' });
  if (db.users.some((u) => u.username.toLowerCase() === username.toLowerCase()))
    return res.status(409).json({ error: 'Это имя уже занято' });

  const user = {
    id: uid(),
    username,
    hash: await bcrypt.hash(password, 10),
    role: db.users.length === 0 ? 'admin' : 'user', // первый зарегистрированный — админ
    createdAt: Date.now(),
  };
  db.users.push(user);
  saveDb();
  setAuthCookie(res, user);
  res.json(publicUser(user));
});

app.post('/api/login', async (req, res) => {
  if (tooMany(req)) return res.status(429).json({ error: 'Слишком много попыток. Подождите немного' });
  const username = String(req.body.username || '').trim().toLowerCase();
  const user = db.users.find((u) => u.username.toLowerCase() === username);
  if (!user || !(await bcrypt.compare(String(req.body.password || ''), user.hash)))
    return res.status(401).json({ error: 'Неверное имя или пароль' });
  setAuthCookie(res, user);
  res.json(publicUser(user));
});

app.post('/api/logout', (req, res) => { res.clearCookie(COOKIE); res.json({ ok: true }); });
app.get('/api/me', auth, (req, res) => res.json(publicUser(req.user)));

/* ---------- видео ---------- */
const YT_RE = /(?:youtube\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/|live\/)|youtu\.be\/)([\w-]{11})/;
function videoFromLink(url) {
  url = String(url || '').trim();
  const m = url.match(YT_RE);
  if (m) return { type: 'youtube', src: m[1], poster: `https://i.ytimg.com/vi/${m[1]}/hqdefault.jpg` };
  if (/^https?:\/\/\S+$/i.test(url)) return { type: 'url', src: url, poster: null };
  return null;
}

const storage = multer.diskStorage({
  destination: UPLOAD_DIR,
  filename: (req, file, cb) =>
    cb(null, uid() + uid() + path.extname(file.originalname).toLowerCase().replace(/[^.\w]/g, '')),
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 ** 3 },
  fileFilter: (req, file, cb) => {
    const ok = file.fieldname === 'video' ? file.mimetype.startsWith('video/') : file.mimetype.startsWith('image/');
    cb(ok ? null : new Error('Неподходящий тип файла'), ok);
  },
});
const removeUpload = (url) => {
  if (url && url.startsWith('/uploads/')) fs.unlink(path.join(UPLOAD_DIR, path.basename(url)), () => {});
};

app.get('/api/videos', auth, (req, res) => res.json([...db.videos].sort((a, b) => b.createdAt - a.createdAt)));

app.post('/api/admin/videos', auth, adminOnly,
  upload.fields([{ name: 'video', maxCount: 1 }, { name: 'poster', maxCount: 1 }]),
  (req, res) => {
    const file = req.files?.video?.[0];
    const poster = req.files?.poster?.[0];
    if (!file) {
      if (poster) removeUpload('/uploads/' + poster.filename);
      return res.status(400).json({ error: 'Выберите видеофайл' });
    }
    const video = {
      id: uid(),
      title: String(req.body.title || file.originalname).trim().slice(0, 100),
      description: String(req.body.description || '').trim().slice(0, 400),
      type: 'file',
      src: '/uploads/' + file.filename,
      poster: poster ? '/uploads/' + poster.filename : null,
      createdAt: Date.now(),
    };
    db.videos.push(video);
    saveDb();
    res.json(video);
  });

app.post('/api/admin/videos/link', auth, adminOnly, (req, res) => {
  const l = videoFromLink(req.body.url);
  if (!l) return res.status(400).json({ error: 'Нужна ссылка на YouTube или прямая ссылка на видеофайл' });
  const video = {
    id: uid(),
    title: String(req.body.title || 'Видео по ссылке').trim().slice(0, 100),
    description: String(req.body.description || '').trim().slice(0, 400),
    ...l,
    createdAt: Date.now(),
  };
  db.videos.push(video);
  saveDb();
  res.json(video);
});

app.delete('/api/admin/videos/:id', auth, adminOnly, (req, res) => {
  const i = db.videos.findIndex((v) => v.id === req.params.id);
  if (i < 0) return res.status(404).json({ error: 'Видео не найдено' });
  const [v] = db.videos.splice(i, 1);
  if (v.type === 'file') { removeUpload(v.src); removeUpload(v.poster); }
  saveDb();
  res.json({ ok: true });
});

/* ---------- комнаты ---------- */
const rooms = new Map();
const newRoomId = () => {
  let id;
  do { id = crypto.randomBytes(4).toString('hex').slice(0, 6).toUpperCase(); } while (rooms.has(id));
  return id;
};

app.post('/api/rooms', auth, (req, res) => {
  let video;
  if (req.body.videoId) {
    video = db.videos.find((v) => v.id === req.body.videoId);
    if (!video) return res.status(404).json({ error: 'Видео не найдено' });
  } else {
    const l = videoFromLink(req.body.url);
    if (!l) return res.status(400).json({ error: 'Вставьте ссылку на YouTube или прямую ссылку на видео' });
    video = { id: null, title: String(req.body.title || 'Видео по ссылке').slice(0, 100), description: '', ...l };
  }
  const room = {
    id: newRoomId(),
    video,
    state: { playing: false, time: 0, updatedAt: Date.now() },
    chat: [],
    members: new Map(),
    emptySince: Date.now(),
  };
  rooms.set(room.id, room);
  res.json({ id: room.id });
});

app.get('/api/rooms/:id', auth, (req, res) => {
  const room = rooms.get(req.params.id.toUpperCase());
  if (!room) return res.status(404).json({ error: 'Комната не найдена' });
  res.json({ id: room.id, video: room.video });
});

// пустые комнаты живут 6 часов
setInterval(() => {
  for (const [id, r] of rooms) if (r.emptySince && Date.now() - r.emptySince > 6 * 3600 * 1000) rooms.delete(id);
}, 10 * 60 * 1000);

/* ---------- страницы ---------- */
const page = (f) => (req, res) => res.sendFile(path.join(ROOT, 'public', f));
app.get('/app', page('app.html'));
app.get('/admin', page('admin.html'));
app.get('/room/:id', page('room.html'));
app.use('/uploads', auth, express.static(UPLOAD_DIR)); // отдаёт видео с поддержкой перемотки (Range)
app.use(express.static(path.join(ROOT, 'public')));

app.use((err, req, res, next) => res.status(400).json({ error: err.message || 'Ошибка' }));

/* ---------- сокеты: синхронизация и чат ---------- */
const io = new Server(server);
const EMOJI = ['❤️', '😂', '😮', '👏', '🔥'];

io.use((socket, next) => {
  const c = cookie.parse(socket.handshake.headers.cookie || '');
  const u = userFromToken(c[COOKIE]);
  if (!u) return next(new Error('unauthorized'));
  socket.data.user = publicUser(u);
  next();
});

const currentTime = (r) => (r.state.playing ? r.state.time + (Date.now() - r.state.updatedAt) / 1000 : r.state.time);
const memberList = (r) => [...new Set([...r.members.values()].map((u) => u.username))];
function pushChat(r, msg) {
  r.chat.push(msg);
  if (r.chat.length > 100) r.chat.shift();
  io.to(r.id).emit('chat', msg);
}

io.on('connection', (socket) => {
  const user = socket.data.user;
  let room = null;

  socket.on('join', (roomId, ack) => {
    const r = rooms.get(String(roomId || '').toUpperCase());
    if (!r) return ack && ack({ error: 'Комната не найдена' });
    room = r;
    socket.join(r.id);
    r.members.set(socket.id, user);
    r.emptySince = null;
    ack && ack({ state: { playing: r.state.playing, time: currentTime(r) }, chat: r.chat, members: memberList(r) });
    io.to(r.id).emit('members', memberList(r));
    pushChat(r, { system: true, text: `${user.username} в зале`, ts: Date.now() });
  });

  socket.on('control', (data) => {
    if (!room || !data) return;
    const time = Number(data.time);
    if (!['play', 'pause', 'seek'].includes(data.action) || !Number.isFinite(time) || time < 0) return;
    const playing = data.action === 'play' ? true : data.action === 'pause' ? false : room.state.playing;
    room.state = { playing, time, updatedAt: Date.now() };
    socket.to(room.id).emit('control', { action: data.action, time, by: user.username });
  });

  socket.on('chat', (text) => {
    if (!room) return;
    text = String(text || '').trim().slice(0, 500);
    if (text) pushChat(room, { user: user.username, text, ts: Date.now() });
  });

  socket.on('reaction', (emoji) => {
    if (room && EMOJI.includes(emoji)) io.to(room.id).emit('reaction', { emoji, user: user.username });
  });

  socket.on('disconnect', () => {
    if (!room) return;
    room.members.delete(socket.id);
    io.to(room.id).emit('members', memberList(room));
    if (room.members.size === 0) room.emptySince = Date.now();
  });
});

server.listen(PORT, () => console.log(`Ложа запущена: http://localhost:${PORT}`));
